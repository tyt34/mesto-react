//import './App.css';
//import logo from './images/logo.svg'
//import profile__img from './images/load.gif'


function Footer() {
  return (
      <footer className="footer">
        <p className="footer__title">© 2020 Mesto Russia</p>
      </footer>
  )
}

export default Footer;
