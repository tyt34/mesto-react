//import './App.css';
import logo from './images/logo.svg'
//import profile__img from './images/load.gif'


function Header() {
  return (

      <header className="header">
        <img className="header__logo" src={logo} alt="Логотип сайта" />
      </header>
      
  )
}

export default Header;
