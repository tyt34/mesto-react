function Test() {
  console.log(' hi ');

  return (
    <div className="test" style={{
      color: "red",
      backgroundColor: "lightblue",
      width: '300px',
      height: '300px',
    }}>
      Hi
    </div>
  )
}

export default Test;
